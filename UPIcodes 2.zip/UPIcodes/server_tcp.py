import socket
import sys
import os
from createJson import makeJson

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
port = 3200
s.bind(('127.0.0.1', port))
print ('Socket binded to port 3125')
s.listen(3)
print ('socket is listening')

c, addr = s.accept()
print ('Got connection from ', addr)
while True:
   msg=c.recv(1024).decode()
   msg = msg.split("/")
   print(msg)
   makeJson(msg[1], msg[2])
   if msg[0]=='0':
      os.system("xcrun simctl push booted blindPolaroid.Page.SMS /Users/kshitizsharma/Developer/UPIcodes/notification.json ")
   else:
      os.system("xcrun simctl push booted blindPolaroid.Page.UPI-Pay /Users/kshitizsharma/Developer/UPIcodes/notification.json ")
c.close()