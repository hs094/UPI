import requests, json


# response = requests.post('http://127.0.0.1:5000/appServer', "dataToSendWasThis")
# print(response.text)

while True:

    app = input("enter app to send notif to(0=sms, 1=upi, 2=pay req(show), 3=pay req(hide)): ")

    z=""
    if app == "0" or app=="1":
        notificationTitle = input("enter notif title: ")
        notificationSubTitle = input("enter notif sub title: ")
        z= app+"/"+notificationTitle+"/"+notificationSubTitle
    elif app == "2":
        #NOTE: notificationTitle needs to match that of string in app delegate 
        # to identify it is a payment request
        notificationTitle = "Payment Request"
        # notificationSubTitle = input("enter notif sub title: ")
        notificationSubTitle = "Raj"
        z= app+"/"+notificationTitle+"/"+notificationSubTitle
    elif app == "3":
        #NOTE: notificationTitle needs to match that of string in app delegate 
        # to identify it is a payment request
        notificationTitle = "Payment Request"
        # notificationSubTitle = input("enter notif sub title: ")
        notificationSubTitle = "Charul"
        z= app+"/"+notificationTitle+"/"+notificationSubTitle
    elif app == "4":
        notificationTitle = "Payment Request"
        notificationSubTitle = "Payment Request From Geet - Rs. 5000"
        z= app+"/"+notificationTitle+"/"+notificationSubTitle
    elif app == "5":
        notificationTitle = "Payment Request"
        notificationSubTitle = "Payment Request From Flipkart - Rs. 2500"
        z= app+"/"+notificationTitle+"/"+notificationSubTitle
    elif app == "6":
        notificationTitle = "Payment Request"
        notificationSubTitle = "Payment Request From UPI Pay - Rs. 5000"
        z= app+"/"+notificationTitle+"/"+notificationSubTitle
    elif app == "7":
        notificationTitle = "Payment Request"
        notificationSubTitle = "Payment Request From Jasbeer - Rs. 1500"
        z= app+"/"+notificationTitle+"/"+notificationSubTitle
   
    # s.sendall(z.encode())    
    response = requests.post('http://192.168.101.11 :5000/appServer', z) 
    print(response.text)
